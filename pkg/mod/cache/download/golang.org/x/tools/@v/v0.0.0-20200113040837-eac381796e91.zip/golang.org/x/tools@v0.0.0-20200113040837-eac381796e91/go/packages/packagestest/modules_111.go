// +build go1.11

package packagestest

func init() {
	All = append(All, Modules)
}
